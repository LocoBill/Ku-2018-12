#ifndef LMX2594_H
#define LMX2594_H

//extern void lmx2594_handle(void);
extern void lmx_2549(void);

#endif
