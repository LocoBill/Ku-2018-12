#ifndef _LMX_2594_H
#define _LMX_2594_H


//void lmx2594_senddata(unsigned char add,unsigned int dat);
void lmx2594_handle(void);


#endif


